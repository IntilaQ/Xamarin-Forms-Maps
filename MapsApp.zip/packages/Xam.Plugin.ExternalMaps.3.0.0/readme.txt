﻿ExternalMaps Readme

Changelog:
[3.0.0]
-Breaking changes: 
---New namespace: Plugin.ExternalMaps
---Now NavigateTo is of type Task<bool> for proper async/await
Enhancements:
-Fix for crash on iOS if address was typed wrong
-Andriod: no longer pop up toast, you are in control
-NavigateTo Now returns a bool if success
-UWP support!

Learn More:
http://www.github.com/jamesmontemagno/Xamarn.Plugins
http://www.xamarin.com/plugins

Created by James Montemagno:
http://twitter.com/jamesmontemagno
http://www.motzcod.es